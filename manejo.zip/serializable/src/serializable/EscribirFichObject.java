/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serializable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *
 * @author Raul
 */
public class EscribirFichObject{
public static void main(String[] args)throws IOException{
Persona persona;
File fichero= new File("src/serializable/persona.dat");
FileOutputStream fileout=new FileOutputStream(fichero);
//Crea el flujo de salida
ObjectOutputStream dataOS= new ObjectOutputStream(fileout);
//conecta el flujo de bytes al flujo de datos
int id[]={1,2,3,4,5,6,7,8,9};
String nombres[ ]={"Ana","Luis Miguel","Alicia","Pedro", "Manuel","Andres", "Julio", "Antonio", "María Jesús"};
int edades[ ]={14, 15, 13, 15, 16, 12, 16, 14, 13};
for(int i=0; i<edades.length; i++){
persona=new Persona(id[i],nombres[i], edades[i]);
dataOS.writeObject (persona); //Escribo la persona en el fichero
}
dataOS.close();
}
}