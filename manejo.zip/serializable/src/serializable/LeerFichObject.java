/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serializable;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 *
 * @author Raul
 */
public class LeerFichObject{
    
    public static void main(String[] args)throws IOException, ClassNotFoundException {
        Persona persona;
        File fichero=new File("src/serializable/persona.dat");
        FileInputStream filein=new FileInputStream(fichero);
        ObjectInputStream dataIS= new ObjectInputStream(filein);
        try{
            while(true){
                        persona=(Persona) dataIS.readObject();
                        System.out.println(" id: "+persona.getId()+", Nombre: " +persona.getNombre()+", edad: " +
                        persona.getEdad());
            }
        }catch(EOFException eo){}
        dataIS.close();
    }
    
}