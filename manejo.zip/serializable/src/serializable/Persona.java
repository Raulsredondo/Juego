/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serializable;

import java.io.Serializable;
public class Persona implements Serializable{
private int id;
private String nombre;
private int edad;
 
public Persona(int id, String nombre, int edad){
this.id = id;
this.nombre=nombre;
this.edad=edad;
}
public Persona(){

}
public void setId(int Id){id=Id;}

public void setNombre(String nom){nombre=nom;}

public void setEdad(int ed){edad=ed;}

public int getId(){return id;}

public String getNombre(){return nombre;}

public int getEdad(){return edad;}

}
