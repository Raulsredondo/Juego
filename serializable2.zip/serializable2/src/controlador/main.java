/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import vista.interfaz;

/**
 *
 * @author Raul
 */
public class main {
     public static void main(String[] args) throws IOException {
        //ejecuta el controlador y este la vista
        new controlador( new interfaz()).iniciar();
       /**
        SELECT NIF, Nombre, Apellido, F_Nacimiento, Nombre_Oficial, Temporada FROM Registro INNER JOIN Futbolista ON Registro._idFut = Futbolista._id INNER JOIN Club ON Registro._idclub = Club._id WHERE Registro._idFut = "1"
        * 
        * 
        * 
        SELECT Nombre_Oficial, NIF, Nombre, Apellido, Temporada FROM Registro INNER JOIN Futbolista ON Registro._idFut = Futbolista._id INNER JOIN Club ON Registro._idclub = Club._id WHERE Registro._idClub = "1"
        */
       
        
    }
}
