/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;


import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import static java.lang.Integer.parseInt;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.ListModel;
import javax.swing.table.DefaultTableModel;
import modelo.manejoFichObject;
import vista.interfaz;

/**
 *
 * @author Raul
 */
public class controlador implements ActionListener, MouseListener {

    /**
     * instancia a nuestra interfaz de usuario
     */
    interfaz vista;
    /**
     * instancia a nuestro modelo
     */
    manejoFichObject fichero = new manejoFichObject();
    
    
    public enum Botones{
        ///JUGADOR///
        _INSERTAR_DEPARTAMENTO,
        _MODIFICAR_DEPARTAMENTO,
        _ELIMINAR_DEPARTAMENTO
    }
    
    public controlador(interfaz vista) {
        this.vista = vista;
    }
    
    public void iniciar() throws IOException {
        // Skin tipo WINDOWS
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            SwingUtilities.updateComponentTreeUI(vista);
            vista.setVisible(true);
        } catch (UnsupportedLookAndFeelException ex) {
        } catch (ClassNotFoundException ex) {
        } catch (InstantiationException ex) {
        } catch (IllegalAccessException ex) {
        }

        // Inicializamos la clase controladorEjemplar y iniciamos su metodo de Inicia
        


        //Declara una accion y añade una escucha al evento producido por el componente
        //Futbolista
        this.vista._INSERTAR_DEPARTAMENTO.setActionCommand("_INSERTAR_DEPARTAMENTO");
        this.vista._INSERTAR_DEPARTAMENTO.addActionListener(this);
        //
        this.vista._MODIFICAR_DEPARTAMENTO.setActionCommand("_MODIFICAR_DEPARTAMENTO");
        this.vista._MODIFICAR_DEPARTAMENTO.addActionListener(this);
        //
        this.vista._ELIMINAR_DEPARTAMENTO.setActionCommand("_ELIMINAR_DEPARTAMENTO");
        this.vista._ELIMINAR_DEPARTAMENTO.addActionListener(this);
        //
        this.vista.jtable1.addMouseListener(this);
        this.vista.jtable1.setModel(fichero.llenarTabla());
        //
        
        this.vista.jtable2.addMouseListener(this);
        this.vista.jtable2.setModel(fichero.llenarTabla());
        //
        

    }
    
    public void seleccionarDepartamento(MouseEvent e) throws IOException {

        int fila = this.vista.jtable2.rowAtPoint(e.getPoint());
        DefaultTableModel seleccionarDep = fichero.llenarTabla();

        if (fila > -1) {
            this.vista._N_Departamento2.setText(String.valueOf(seleccionarDep.getValueAt(fila, 0)));
            this.vista._Nombre2.setText(String.valueOf(seleccionarDep.getValueAt(fila, 1)));
            this.vista._Localidad2.setText(String.valueOf(seleccionarDep.getValueAt(fila, 2)));;
        }
    }
   
    public void seleccionarDep2(MouseEvent e) throws IOException {

        int fila = this.vista.jtable2.rowAtPoint(e.getPoint());
        DefaultTableModel seleccionarDep = fichero.llenarTabla();

        if (fila > -1) {
            this.vista._N_Departamento2.setText(String.valueOf(seleccionarDep.getValueAt(fila, 0)));
            this.vista._Nombre2.setText(String.valueOf(seleccionarDep.getValueAt(fila, 1)));
            this.vista._Localidad2.setText(String.valueOf(seleccionarDep.getValueAt(fila, 2)));
        }
    }
  
    public void mouseClicked(MouseEvent me) {
        
    }

    
    public void mousePressed(MouseEvent me) {
   }

    
    public void mouseReleased(MouseEvent me) {
        
    }

    
    public void mouseEntered(MouseEvent me) {
        
    }

    
    public void mouseExited(MouseEvent me) {
        
    }
    
    public void actionPerformed(ActionEvent e) {
        switch (Botones.valueOf(e.getActionCommand())){

            case _INSERTAR_DEPARTAMENTO:

        {
            try {
                if (this.fichero.InsertarFichObject(
                        this.vista._N_Departamento1.getText(),
                        this.vista._Nombre1.getText(),
                        this.vista._Localidad1.getText()
                )) {
                    this.vista.jtable1.setModel(this.fichero.llenarTabla());
                    this.vista.jtable2.setModel(this.fichero.llenarTabla());
                    
                    JOptionPane.showMessageDialog(vista, "Exito: Nuevo Futbolista Introducido.");
                    this.vista._N_Departamento1.setText("");
                    this.vista._Nombre1.setText("");
                    this.vista._Localidad1.setText("");
                } else //ocurrio un error
                {
                    JOptionPane.showMessageDialog(vista, "Error: Los datos son incorrectos.");
                }
            } catch (IOException ex) {
                
            } catch (ClassNotFoundException ex) {
                
            }
        }
            break;
            case _MODIFICAR_DEPARTAMENTO:
                if (this.vista._N_Departamento2.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No hay datos para modificar, seleccione un registro de la tabla.");
                    } else {

            try {
                this.fichero.ModificarFichObject(
                        this.vista._N_Departamento2.getText(),
                        this.vista._Nombre2.getText(),
                        this.vista._Localidad2.getText());
            } catch (IOException ex) {
                Logger.getLogger(controlador.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(controlador.class.getName()).log(Level.SEVERE, null, ex);
            }

            try {
                this.vista.jtable1.setModel(this.fichero.llenarTabla());
            } catch (IOException ex) {
                Logger.getLogger(controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                this.vista.jtable2.setModel(this.fichero.llenarTabla());
            } catch (IOException ex) {
                Logger.getLogger(controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
                        JOptionPane.showMessageDialog(vista, "Exito: Futbolista Modificado.");

                    }
            break;
            
            case _ELIMINAR_DEPARTAMENTO:
        {
            try {
                if (this.fichero.EliminarFichObject(this.vista._N_Departamento2.getText()))
                {
                    
                    this.vista.jtable1.setModel(this.fichero.llenarTabla());
                    this.vista.jtable2.setModel(this.fichero.llenarTabla());
                    JOptionPane.showMessageDialog(vista,"Exito: Registro eliminado.");
                    this.vista._N_Departamento2.setText("");
                    this.vista._Nombre2.setText("") ;
                    this.vista._Localidad2.setText("");
                }
            } catch (IOException ex) {
                Logger.getLogger(controlador.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            break;
        }
    }
}
    
