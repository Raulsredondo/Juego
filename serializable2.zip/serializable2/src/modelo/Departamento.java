/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.io.Serializable;
/**
 *
 * @author Raul
 */
public class Departamento implements Serializable{
    private int Ndepartamento;
    private String Nombre;
    private String Localidad;
    
    public Departamento(int Ndepartamento, String Nombre, String Localidad){
        this.Localidad = Localidad;
        this.Ndepartamento = Ndepartamento;
        this.Nombre = Nombre;
    }
    
    public Departamento(){
    
    }

    public int getNdepartamento() {
        return Ndepartamento;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getLocalidad() {
        return Localidad;
    }

    public void setNdepartamento(int Ndepartamento) {
        this.Ndepartamento = Ndepartamento;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setLocalidad(String Localidad) {
        this.Localidad = Localidad;
    }
    
   
    
  
}

