/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;


import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Raul
 */
public class manejoFichObject {
    
    HashMap <Integer, Departamento> hashMapObject= new HashMap <Integer, Departamento>();
    File fichero= new File("src/departamento.dat");
    Departamento departamento;
    
    
    public DefaultTableModel llenarTabla() throws FileNotFoundException, IOException {
        FileOutputStream fileout=new FileOutputStream(fichero);
        ObjectOutputStream dataOS= new ObjectOutputStream(fileout);
        
        Departamento dep = new Departamento(1, "Hola", "hOLA");
        hashMapObject.put(1, dep);
        dataOS.writeObject(hashMapObject);
        
		DefaultTableModel plantilla=new DefaultTableModel();
		String headers[]= {"ID","Nombre","Localidad"};
		String[][] tabla=new String[hashMapObject.size()][3];
		int id;
		int i=0;
		String nombre, localidad;
		for (Entry<Integer, Departamento> dpto : hashMapObject.entrySet()) {
			tabla[i][0]=Integer.toString(dpto.getKey());
			tabla[i][1]=dpto.getValue().getNombre();
			tabla[i][2]=dpto.getValue().getLocalidad();
			i++;
			}
		plantilla.setDataVector(tabla, headers);
		return plantilla;
	}
    
    
    
    public boolean InsertarFichObject (String id, String nombre, String localidad) throws IOException, ClassNotFoundException{
        int iTest = Integer.parseInt(id);
        FileOutputStream fileout=new FileOutputStream(fichero);
        ObjectOutputStream dataOS= new ObjectOutputStream(fileout);
        departamento = new Departamento(iTest, nombre, localidad);
        Departamento dep = new Departamento(1, "Hola", "hOLA");
        hashMapObject.put(iTest, departamento);
        hashMapObject.put(1, dep);
        try{
            dataOS.writeObject(hashMapObject);
        
        }catch(EOFException eo){}
        dataOS.close();
        return false;
    }
    public boolean EliminarFichObject (String id) throws IOException, ClassNotFoundException{
         int iTest = Integer.parseInt(id);
        FileInputStream filein=new FileInputStream(fichero);
        ObjectInputStream dataIS= new ObjectInputStream(filein);
        FileOutputStream fileout=new FileOutputStream(fichero);
        ObjectOutputStream dataOS= new ObjectOutputStream(fileout);
        try{
            hashMapObject=(HashMap) dataIS.readObject();
            hashMapObject.remove(iTest);
                    dataOS.writeObject(hashMapObject);
        }catch(EOFException eo){}
        dataOS.close();
        dataIS.close();
        return false;
    }
    public void ModificarFichObject (String id, String nombre,String localidad) throws IOException, ClassNotFoundException{
         int iTest = Integer.parseInt(id);
        FileOutputStream fileout=new FileOutputStream(fichero);
        ObjectOutputStream dataOS= new ObjectOutputStream(fileout);
        departamento = new Departamento(iTest, nombre, localidad);
        hashMapObject.put(iTest, departamento);
        try{
            
            dataOS.writeObject(hashMapObject);
            
        }catch(EOFException eo){}
        dataOS.close();
    }
}




/*public void BuscarFichObject(int id) throws IOException, ClassNotFoundException{
        FileInputStream filein=new FileInputStream(fichero);
        ObjectInputStream dataIS= new ObjectInputStream(filein);
        try{
            hashMapObject=(HashMap) dataIS.readObject();
            hashMapObject.get(id);
            /*
            Object[][] data = new String[registrosFut][7];
           int i=0;
          while(res.next()){
                  data[i][0] = res.getString(1);
                  data[i][1] = res.getString(2);
                  data[i][2] = res.getString(3);
                  data[i][3] = res.getString(4);
                  data[i][4] = res.getString(5);
                  data[i][5] = res.getString(6);
               i++;
            }
        
            String data[][]=new String[hashMapObject.size()] [3];
            for(int i = 0; i< hashMapObject.size(); i++){
                data [i] [0]= hashMapObject.get(i)departamento.getNdepartamento();
                data [i] [1]= hashMapObject.get(i)departamento.getNombre();
                data [i] [2]= hashMapObject.get(i)departamento.getLocalidad();
                i++;
            
            }
            
            
            
            
            
            
            
        }catch(EOFException eo){}
        dataIS.close();
    
    }
    */